export { default as About } from './about_us/About';
export { default as Discover } from './discover/Discover';
export { default as Home } from './home/Home';
export { default as Login } from './login/Login';
export { default as Product_page } from './product_page/Product_page';
export { default as Signup } from './signup/SignUp';
export {default as Dashboard } from './dashboard/Dashboard';
export { default as Sell } from './sell/Sell';
export { default as Checkout } from './checkout/checkout';