import React from 'react'
import './product_page.css';

const Product_page = () => {
    return (
        <div>Product_page</div>
    )
}

export default Product_page