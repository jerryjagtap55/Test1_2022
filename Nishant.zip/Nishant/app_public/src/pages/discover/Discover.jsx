import React from 'react';
import './discover.css'

const Discover = () => {
    return (
        <div>Discover</div>
    )
}

export default Discover