export { default as About }
from './about_us/About';
export { default as Discover }
from './discover/Discover';
export { default as Home }
from './home/Home';
export { default as Login }
from './login/Login';
export { default as Product_page }
from './product_page/Product_page';
export { default as Signup }
from './signup/SignUp';