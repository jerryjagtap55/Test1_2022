import React from 'react';
import './about.css';

const About = () => {
    return (
        <div>About</div>
    )
}

export default About