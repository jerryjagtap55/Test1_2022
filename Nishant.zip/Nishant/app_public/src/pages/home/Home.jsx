import React from 'react';
import './home.css'

const Home = () => {
    return (
        <div>hello Home</div>
    )
}

export default Home