import React from 'react';
import './hero.css';

const Hero = () => {
    return (
        <div>Hero</div>
    )
}

export default Hero