export { default as Card }
from './card/Card';
export { default as Features }
from './features/Features';
export { default as Footer }
from '../components/footer/Footer';
export { default as Hero }
from './hero/Hero';