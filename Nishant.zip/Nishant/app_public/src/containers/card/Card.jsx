import React from 'react';
import './card.css';

const Card = () => {
  return (
    <div>Card</div>
  )
}

export default Card