import React from 'react';
import './features.css';

const features = () => {
    return (
        <div>features</div>
    )
}

export default features